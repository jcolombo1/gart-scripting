import org.springframework.web.client.ResourceAccessException
import grails.converters.*
//import groovyx.net.http.*
import groovyx.net.http.*


includeTargets << grailsScript("_GrailsInit")

gartEM = null
magicLinkLeyend = "Server running. Browse to "  // strictly!! (fixed Eclipse console??)


// --------------------------------------------------------------------------------------------------------------------

target(check2Cloud: "The description of the script goes here!" ) {
	

	depends ( createGartEM )
	
	def result = doREST( op: "check" )

	displayResult(result)

}
setDefaultTarget(check2Cloud)

// -------------------------------------------------------------------------------------

target(send2Cloud: "The description of the script goes here!") {

	depends ( createGartEM )
	
	def result = doREST( op: "send", full: true )

	if (!result.error) result.success = "GArt IDE ${magicLinkLeyend}${result.link}" 

	displayResult(result)
	
}


	
// -------------------------------------------------------------------------------------

doREST = { args ->

	 
	def http = new HTTPBuilder( 'http://twitter.com/statuses/' )
	
	restBuilder = (classLoader.loadClass('grails.plugins.rest.client.RestBuilder')).newInstance()
	
	def gartHost = 'http://localhost:8090/gart-ide'
	def gartUser = 'admin'    //@@@@@@@@@@@@@@@@@@ test
	def gartPass = 'laclave'     //@@@@@@@@@@@@@@@@@@ test
	
	def projectId = gartEM.appProyect['pid'] ? gartEM.appProyect['pid'] : '0'
	boolean full = args?.full ? args.full : false
	  
	restURL = "${gartHost}/rest/${gartUser}/${projectId}/${args.op}"

	def result = [:]
	 
	try {
		
		result.resp = restBuilder.post(restURL) {
			auth gartUser, gartPass
			body gartEM.getProjectJsonString(full)
		}
		result.link = "${gartHost}/rest/${gartUser}/${projectId}"
		println result.resp.json
		result.success = "successful ${args.op}..."
		
	} catch (ResourceAccessException e) {
		result = [ error: "No connection is achieved with the application IDE. Check your Internet access connection, or try again later.", exit: 1 ]
	} catch (e) {
		result = [ error: e, exit: 1 ]
	}

	result
}


//def http = new HTTPBuilder( 'http://twitter.com/statuses/' )
// 
//http.get( path: 'user_timeline.json',
//		query: [id:'httpbuilder', count:5] ) { resp, json ->
//		 
//	println resp.status
//	 
//	json.each {  // iterate over JSON 'status' object in the response:
//		println it.created_at
//		println '  ' + it.text
//	}
//}
//



// --------------------------------------------------------------------------------------------------------------------

displayResult = { result ->
	if (result) {
		if ( result.error )
			event 'StatusError', [ "$iam : " + result.error ]
		else if (result.success)
			event 'StatusUpdate', [ "$iam : "+ result.success ]
			
		if (result.exit)
			exit result.exit
	}
}
