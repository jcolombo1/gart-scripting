package gart.demo

class GartDemo {

	String name
	String email

    static constraints = {
    }
}
